/**********************************************************************************************
** Program: determinant.h
** Author: Hailey Wilder
** Description: file header for determinant 
***********************************************************************************************/
#ifndef DETERMINANT_H
#define DETERMINANT_H

int determinant(int arr[][3], int sizeSq);

#endif