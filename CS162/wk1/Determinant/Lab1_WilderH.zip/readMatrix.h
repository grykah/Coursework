/********************************************************************************************
** Program: readMatrix.h
** Author: Hailey Wilder
** Description: header for readMatrix
*********************************************************************************************/
#ifndef READMATRIX_H
#define READMATRIX_H

void readMatrix(int **ar, int sizeSq);

#endif