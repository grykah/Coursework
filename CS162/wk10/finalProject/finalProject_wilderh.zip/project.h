<NotepadPlus>
    <Project name="Final">
        <File name="main.cpp" />
        <File name="Dungeon.hpp" />	
        <File name="Dungeon.cpp" />
        <File name="GuestBath.hpp" />
        <File name="GuestBath.cpp" />
        <File name="Door.hpp" />
        <File name="Door.cpp" />
        <File name="SittingArea.hpp" />
        <File name="SittingArea.cpp" />
        <File name="MasterBedroom.hpp" />
        <File name="MasterBedroom.cpp" />
        <File name="Inventory.hpp" />
        <File name="Inventory.cpp" />
        <File name="Player.hpp" />
        <File name="Player.cpp" />
        <File name="Room.hpp" />
        <File name="Room.cpp" />
        <File name="Game.hpp" />
        <File name="Game.cpp" />
        <File name="makefile" />
    </Project>
</NotepadPlus>
